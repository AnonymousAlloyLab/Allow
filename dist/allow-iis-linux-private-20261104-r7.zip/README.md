# Allow: private IIS + Linux deployment package

Read [the deployment guide](docs/iis-deployment.md) before installation.
IIS provides HTTPS on Windows; a strict SSH tunnel reaches the existing Linux
loopback backend. Native Windows backend execution is not supported.

The archive contains no workspace data, tokens, keys or trained models. Verify
the archive SHA-256 sidecar obtained over a trusted channel, extract into a short
service-owned Linux directory such as `/opt/allow` with `umask 077` and mode0700.
Preserve the normalized archive modes; no installation directory may be group or
other writable. The private instance configuration must be mode0600.
Do not put the archive or extracted Linux files in an IIS web root.

Generate nonsecret instance files:

```bash
/usr/bin/python3 -I -B deploy/configure.py --origin https://allow.example.com \
  --output /opt/allow/generated-instance --install-root /opt/allow
install -m 600 generated-instance/linux/instance.json deploy/instance.json
/usr/bin/python3 -I -B deploy/linux/setup.py --config deploy/instance.json
```

Always retain the `-I -B` isolation flags. Setup/service reject local application
bytecode, extra executable/configuration inputs and unsafe ownership. Fresh
initialization refuses old generated tools. A shared persistent flock prevents
competing supervisors from touching the active workspace. Do not delete its
lock or ownership journals. Managed dependency semantics remain separately trusted.

The last command verifies the manifest and host prerequisites without creating
a database. Add `--initialize` only for the explicit fresh-workspace setup in
the guide. Install the rendered systemd unit, then configure the SSH tunnel and
the dedicated IIS site using the included PowerShell scripts.

The IIS installer now supports `-PreflightOnly` and stages a site with auto-start
disabled. It does not start the site or open public ingress. Keep the site stopped
until the named target, audience and native acceptance are resolved. An HTTPS
URL with privately shared operator access is supported by the existing workspace;
anonymous or separate-user access is not supplied by this package.

Run `python -I -B deploy/probe_public.py --origin https://allow.example.com`
from an approved client after deliberately starting the staged route with restricted
ingress. It checks eight unauthenticated HTTPS boundaries without a real token;
its PASS does not establish complete deployment acceptance. See the guide for
the authenticated checks, tunnel supervision and controlled exposure sequence.

Advisory validation selects fresh Tier-1 JVMs as an operator opt-in experiment;
durable/solver paths retain DEFAULT and warm pooling remains disabled. Tier-1
was faster in the prior paired HTTP measurement, but missed the 300-ms target.
Set `advisory_profile` to `DEFAULT` in the instance configuration to roll back.

Windows/IIS execution and actual production-host acceptance remain open. This
is an operator-private transfer artifact, not commercial-release approval.
