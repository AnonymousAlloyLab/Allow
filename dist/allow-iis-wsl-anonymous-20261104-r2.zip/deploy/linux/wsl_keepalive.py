#!/usr/bin/python3
"""Keep an explicit WSL invocation alive while the preinstalled service is active."""
import sys
if not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    raise SystemExit('Invoke with /usr/bin/python3 -I -B')

import subprocess
import time


def main():
    """Observe only the fixed service; lifecycle ownership remains with Windows."""
    while True:
        result = subprocess.run(['/usr/bin/systemctl', 'is-active', '--quiet', 'allow.service'],
                                stdin=subprocess.DEVNULL, timeout=10, check=False)
        if result.returncode:
            raise SystemExit('Selected service is not active')
        time.sleep(5)


if __name__ == '__main__':
    main()
