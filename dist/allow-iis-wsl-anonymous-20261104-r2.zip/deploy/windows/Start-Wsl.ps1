<# .SYNOPSIS Foreground explicit selected-distribution supervisor; installs no task. #>
[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$Distribution,
 [ValidatePattern('^[a-z_][a-z0-9_-]*$')][string]$LinuxAccount='allow',
 [ValidateRange(1,10)][int]$MaximumAttempts=3
)
$ErrorActionPreference='Stop'
$wsl=(Get-Command wsl.exe -ErrorAction Stop).Source
$hash=[System.Security.Cryptography.SHA256]::Create()
$name=([BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($Distribution)))).Replace('-','')
$mutex=New-Object System.Threading.Mutex($false,"Global\AllowWsl-$name")
$locked=$false
$owned=$false
try {
 $locked=$mutex.WaitOne(0)
 if (-not $locked) { throw 'A supported supervisor already owns this distribution.' }
 $state=& $wsl --distribution $Distribution --user root --exec systemctl show allow.service --property=ActiveState --value
 if ($LASTEXITCODE -ne 0 -or $state.Trim() -notin @('inactive','failed')) { throw 'Existing or uncertain service is not owned by this invocation.' }
 for ($attempt=1; $attempt -le $MaximumAttempts; $attempt++) {
  & $wsl --distribution $Distribution --user root --exec systemctl start allow.service
  if ($LASTEXITCODE -ne 0) { throw 'Selected service failed to start.' }
  $owned=$true
  & $wsl --distribution $Distribution --user $LinuxAccount --exec /usr/bin/python3 -I -B /opt/allow/deploy/linux/wsl_keepalive.py
  if ($LASTEXITCODE -eq 0) { break }
  if ($attempt -eq $MaximumAttempts) { throw 'Bounded supervisor restart budget exhausted.' }
  Start-Sleep -Seconds ([Math]::Min(30,5*$attempt))
 }
} finally {
 if ($owned) {
  & $wsl --distribution $Distribution --user root --exec systemctl stop allow.service
  if ($LASTEXITCODE -ne 0) { Write-Error 'Owned service stop uncertain; inspect target before retry.' }
 }
 if ($locked) { $mutex.ReleaseMutex() }
 $mutex.Dispose()
 $hash.Dispose()
}
